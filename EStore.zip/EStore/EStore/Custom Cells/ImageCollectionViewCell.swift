//
//  ImageCollectionViewCell.swift
//  EStore
//
//  Created by student on 11/20/21.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    func setupImageWith(itemImage: UIImage){
        imageView.image = itemImage
    }
}
