//
//  Constants.swift
//  EStore
//
//  Created by student on 10/29/21.
//

import Foundation
enum Constats {
    static let publishableKey = "pk_test_51K1gn4GOenTfkRgL6y1CDNyUVXA32CQ6qVM5Bh2ftOP0YXCoD0JSLoBY40titjcqpfcmtZqOulFgLPknvK8Dn55H00lXTx4HVr"
    static let baseURLString = "http://localhost:3000/"
    static let defaultCurrency = "usd"
    static let defaultDescription = "Purchase from Market"
}

//IDS and Keys
public let kFILEREFERENCE = "gs://estore-ba52d.appspot.com"
public let kALGFOLIA_APP_ID = "UQFB2J77B1"
public let kALGOLIA_SEARCH_KEY = "4f5ba889ab72b68fc3d4e4b03070cc71"
public let kALGOLIA_ADMIN_KEY = "6c0f09e1d6e5deba7df751a7b8e0fe25"

//Firebase Headers
public let kUSER_PATH = "User"
public let kCATEGORY_PATH = "Category"
public let kITEMS_PATH = "Items"
public let kBASKET_PATH = "Basket"



//Category
public let kNAME = "name"
public let kIMAGENAME = "imageName"
public let kOBJECTID = "objectId"

//Item
public let kCATEGORYID = "categoryId"
public let kDESCRIPTION = "description"
public let kPRICE = "price"
public let kIMAGELINKS = "imageLinks"

//Basket
public let kOWNERID = "ownerId"
public let kITEMIDS = "itemIds"

//User
public let kEMAIL = "email"
public let kFIRSTNAME  = "firstName"
public let kLASTNAME  = "lastName"
public let kFULLNAME  = "fullName"
public let kCURRENTUSER  = "currentUser"
public let kFULLADDRESS  = "fullAddress"
public let kONBOARD  = "onBoard"
public let kPURCHASEDITEMIDS  = "purchasedItemIds"
